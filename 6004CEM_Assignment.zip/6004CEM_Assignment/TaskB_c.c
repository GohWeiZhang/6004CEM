#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>
#include <string.h>

// Function to initialize matrix with random values
void initialize_matrix(double **matrix, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            matrix[i][j] = (double)rand() / RAND_MAX;
        }
    }
}

// Function to allocate 2D matrix
double** allocate_matrix(int size) {
    double **matrix = (double**)malloc(size * sizeof(double*));
    for (int i = 0; i < size; i++) {
        matrix[i] = (double*)malloc(size * sizeof(double));
    }
    return matrix;
}

// Function to deallocate 2D matrix
void deallocate_matrix(double **matrix, int size) {
    for (int i = 0; i < size; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

// Matrix multiplication with outer loop parallelization
void matrix_multiply_outer_parallel(double **A, double **B, double **C, int size, int num_threads) {
    omp_set_num_threads(num_threads);
    
    #pragma omp parallel for
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            C[i][j] = 0.0;
            for (int k = 0; k < size; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

// Matrix multiplication with inner loop parallelization
void matrix_multiply_inner_parallel(double **A, double **B, double **C, int size, int num_threads) {
    omp_set_num_threads(num_threads);
    
    for (int i = 0; i < size; i++) {
        #pragma omp parallel for
        for (int j = 0; j < size; j++) {
            C[i][j] = 0.0;
            for (int k = 0; k < size; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

// Function to run performance test (run multiply and calculate the average time it takes to finish)
double run_performance_test(double **A, double **B, double **C, int size, int num_threads, 
                           void (*multiply_func)(double**, double**, double**, int, int), 
                           int num_runs) {
    double total_time = 0.0;
    
    for (int run = 0; run < num_runs; run++) {
        double start_time = omp_get_wtime();
        multiply_func(A, B, C, size, num_threads);
        double end_time = omp_get_wtime();
        total_time += (end_time - start_time);
    }
    
    return total_time / num_runs;
}

int main() {
    const int num_runs = 10;
    const int thread_counts[] = {1, 4, 8, 16};
    const int matrix_sizes[] = {50, 500};
    const int num_thread_counts = 4;
    const int num_matrix_sizes = 2;
    
    printf("OpenMP Matrix Multiplication Performance Test\n");
    printf("============================================\n\n");
    
    // Results storage
    double outer_results[2][4]; // [matrix_size_index][thread_count_index]
    double inner_results[2][4];
    
    srand(time(NULL));
    
    for (int size_idx = 0; size_idx < num_matrix_sizes; size_idx++) {
        int size = matrix_sizes[size_idx];
        
        printf("Testing with %dx%d matrices:\n", size, size);
        printf("---------------------------\n");
        
        // Allocate matrices
        double **A = allocate_matrix(size);
        double **B = allocate_matrix(size);
        double **C = allocate_matrix(size);
        
        // Initialize matrices
        initialize_matrix(A, size);
        initialize_matrix(B, size);
        
        printf("Threads\tOuter Loop (s)\tInner Loop (s)\n");
        printf("-------\t--------------\t--------------\n");
        //test multiplication 1,4,8,6 thread count and store average time
        for (int thread_idx = 0; thread_idx < num_thread_counts; thread_idx++) {
            int num_threads = thread_counts[thread_idx];
            
            // Test outer loop parallelization
            double outer_time = run_performance_test(A, B, C, size, num_threads, 
                                                   matrix_multiply_outer_parallel, num_runs);
            outer_results[size_idx][thread_idx] = outer_time;
            
            // Test inner loop parallelization
            double inner_time = run_performance_test(A, B, C, size, num_threads, 
                                                   matrix_multiply_inner_parallel, num_runs);
            inner_results[size_idx][thread_idx] = inner_time;
            
            printf("%d\t%.6f\t\t%.6f\n", num_threads, outer_time, inner_time);
        }
        
        printf("\n");
        
        // Deallocate matrices
        deallocate_matrix(A, size);
        deallocate_matrix(B, size);
        deallocate_matrix(C, size);
    }
    
    // Summary and analysis
    printf("PERFORMANCE SUMMARY\n");
    printf("==================\n\n");
    //loop through 1,4,8,16
    for (int size_idx = 0; size_idx < num_matrix_sizes; size_idx++) {
        int size = matrix_sizes[size_idx];
        printf("For %dx%d matrices:\n", size, size);
        
        // Find which approach is faster for each thread count
        int outer_wins = 0, inner_wins = 0;
        
        for (int thread_idx = 0; thread_idx < num_thread_counts; thread_idx++) {
            int threads = thread_counts[thread_idx];
            double outer_time = outer_results[size_idx][thread_idx]; //run multiplication
            double inner_time = inner_results[size_idx][thread_idx];
            
            if (outer_time < inner_time) {
                outer_wins++;
                printf("  %d threads: Outer loop faster (%.6f vs %.6f seconds)\n", 
                       threads, outer_time, inner_time);
            } else {
                inner_wins++;
                printf("  %d threads: Inner loop faster (%.6f vs %.6f seconds)\n", 
                       threads, inner_time, outer_time);
            }
        }
        
        // Overall winner for this matrix size
        if (outer_wins > inner_wins) {
            printf("  OVERALL: Outer loop parallelization is faster for %dx%d matrices\n", size, size);
        } else if (inner_wins > outer_wins) {
            printf("  OVERALL: Inner loop parallelization is faster for %dx%d matrices\n", size, size);
        } else {
            printf("  OVERALL: Both approaches perform similarly for %dx%d matrices\n", size, size);
        }
        printf("\n");
    }
    
    return 0;
}
