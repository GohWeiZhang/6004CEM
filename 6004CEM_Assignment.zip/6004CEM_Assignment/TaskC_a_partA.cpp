#include <iostream>
#include <mpi.h>

using namespace std;

int main(int argc, char** argv) {
    int rank, size;

    // Initialize MPI
    MPI_Init(&argc, &argv);

    // Get the rank of the current process
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    // Get the total number of processes
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Print hello message from each process
    cout << "Hello World from process " << rank << " of " << size << " processes" << endl;

    // Finalize MPI
    MPI_Finalize();

    return 0;
}

