#include <iostream>
#include <mpi.h>
#include <string>
#include <cstring>

#define MAX_PROCESSES 4

using namespace std;

int main(int argc, char** argv) {
    int rank, size;
    int requested_procs = 0;
    char processor_name[MPI_MAX_PROCESSOR_NAME];
    int name_len;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Get_processor_name(processor_name, &name_len);

    if (rank == 0) {
        cout << "Enter number of processors to use (max " << MAX_PROCESSES << "): ";
        cout.flush(); // Ensure prompt appears before input
        cin >> requested_procs;

        if (requested_procs > MAX_PROCESSES || requested_procs < 1) {
            cerr << "Error: You requested an invalid number of processors (1-" << MAX_PROCESSES << ")." << endl;
        }
    }

    // Broadcast user input to all processes
    MPI_Bcast(&requested_procs, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // Exit if input is invalid
    if (requested_procs > MAX_PROCESSES || requested_procs < 1) {
        MPI_Finalize();
        return 1;
    }

    // Only allow ranks < requested_procs to continue
    if (rank < requested_procs) {
        cout << "Hello from process " << rank << " of " << requested_procs 
             << " on " << processor_name << endl;
    }

    MPI_Barrier(MPI_COMM_WORLD);

    if (rank == 0) {
        cout << "\n--- MPI Program Summary ---" << endl;
        cout << "User requested processors: " << requested_procs << endl;
        cout << "Program was launched with " << size << " MPI processes." << endl;
        cout << "Only " << requested_procs << " processes participated in output." << endl;
    }

    MPI_Finalize();
    return 0;
}

