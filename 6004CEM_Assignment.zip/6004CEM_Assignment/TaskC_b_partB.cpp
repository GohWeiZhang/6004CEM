#include <mpi.h>
#include <iostream>
#include <cstring>

using namespace std;

int main(int argc, char** argv) {
    int rank, size;
    MPI_Status status;

    MPI_Init(&argc, &argv);                   // Initialize MPI environment
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);     // Get the current process rank
    MPI_Comm_size(MPI_COMM_WORLD, &size);     // Get the total number of processes

    const int MAX_MSG_LEN = 100;
    char message[MAX_MSG_LEN];

    if (rank == 0) {
        cout << "Master: Hello slaves, give me your messages" << endl;

        for (int i = 1; i < size; ++i) {
            MPI_Recv(message, MAX_MSG_LEN, MPI_CHAR, i, 0, MPI_COMM_WORLD, &status);
            cout << "Message received from process " << i << " : " << message << endl;
        }

    } else {
        // Create custom message based on rank
        if (rank == 1)
            strcpy(message, "Hello, I am John");
        else if (rank == 2)
            strcpy(message, "Hello, I am Mary");
        else if (rank == 3)
            strcpy(message, "Hello, I am Susan");
        else
            snprintf(message, MAX_MSG_LEN, "Hello, I am process %d", rank); // fallback for any extra process

        MPI_Send(message, strlen(message) + 1, MPI_CHAR, 0, 0, MPI_COMM_WORLD); // include null terminator
    }

    MPI_Finalize(); // Finalize the MPI environment
    return 0;
}

