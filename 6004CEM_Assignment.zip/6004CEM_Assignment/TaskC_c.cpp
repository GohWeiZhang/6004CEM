#include <mpi.h>
#include <iostream>
#include <cstring>
#include <string>

using namespace std;

int main(int argc, char** argv) {
    int rank, size;
    const int tag = 100;
    const int wrong_tag = 101;
    const int reply_tag = 0;
    const int MAX_MSG_LEN = 100;
    char message[MAX_MSG_LEN];
    MPI_Status status;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 0) {
        cout << "Master: Sending message to slaves..." << endl;

        for (int i = 1; i < size; i++) {
            string msg = "Ready?";
            MPI_Send(msg.c_str(), msg.length() + 1, MPI_CHAR, i, tag, MPI_COMM_WORLD);
        }

        for (int i = 1; i < size; i++) {
            MPI_Recv(message, MAX_MSG_LEN, MPI_CHAR, i, reply_tag, MPI_COMM_WORLD, &status);
            cout << "Message received from process " << i << ": " << message << endl;
        }
    } else {
        MPI_Recv(message, MAX_MSG_LEN, MPI_CHAR, 0, wrong_tag, MPI_COMM_WORLD, &status);
        cout << "Process " << rank << " received: " << message << endl;

        string reply = "Hello from process " + to_string(rank);
        MPI_Send(reply.c_str(), reply.length() + 1, MPI_CHAR, 0, reply_tag, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
}

