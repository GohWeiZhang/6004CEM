#include <mpi.h>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    int rank, size;
    MPI_Status status;

    MPI_Init(&argc, &argv);                   // Initialize MPI environment
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);     // Get the current process rank
    MPI_Comm_size(MPI_COMM_WORLD, &size);     // Get the total number of processes

    if (rank == 0) {
        cout << "Master: Hello slaves give me your messages" << endl;

        for (int i = 1; i < size; i++) {
            int slave_rank;
            MPI_Recv(&slave_rank, 1, MPI_INT, i, 0, MPI_COMM_WORLD, &status);
            cout << "Message received from process " << slave_rank << " : Hello back" << endl;
        }

    } else {
        // Send rank to master
        MPI_Send(&rank, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Finalize(); // Finalize the MPI environment
    return 0;
}

