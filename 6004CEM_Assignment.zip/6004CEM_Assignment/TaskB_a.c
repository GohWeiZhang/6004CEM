#include <stdio.h>
#include <omp.h>
#include <stdlib.h>

int main() {
    int num_threads;
    
    printf("=== OpenMP Hello World Program ===\n\n");
    
    // Part 1: Default 10 threads
    printf("Part 1: Running with 10 threads \n");
    printf("----------------------------------------\n");
    
    #pragma omp parallel num_threads(10)
    {
        int thread_id = omp_get_thread_num();
        int total_threads = omp_get_num_threads();
        
        #pragma omp critical
        {
            printf("Hello World from thread %d of %d threads!\n", thread_id, total_threads);
        }
    }
    
    printf("\n");
    
    // Part 2: Using environment variable
    printf("Part 2: Using OMP_NUM_THREADS environment variable\n");
    printf("--------------------------------------------------\n");
    printf("Current OMP_NUM_THREADS setting: ");
    
    //read environment variable
    char* env_threads = getenv("OMP_NUM_THREADS");
    if (env_threads != NULL) {
        printf("%s\n", env_threads);
    } else {
        printf("Not set (will use system default)\n");
    }
    
    #pragma omp parallel
    {
        int thread_id = omp_get_thread_num();
        int total_threads = omp_get_num_threads();
        
        #pragma omp critical
        {
            printf("Hello World from thread %d of %d threads!\n", thread_id, total_threads);
        }
    }
    
    printf("\n");
    
    // Part 3: User input for number of threads
    printf("Part 3: User-specified number of threads\n");
    printf("---------------------------------------\n");
    printf("Enter the number of threads you want to create: ");
    
    if (scanf("%d", &num_threads) != 1 || num_threads <= 0) {
        printf("Invalid input. Using default of 4 threads.\n");
        num_threads = 4;
    }
    
    printf("Creating %d threads...\n", num_threads);
    
    #pragma omp parallel num_threads(num_threads)
    {
        int thread_id = omp_get_thread_num();
        int total_threads = omp_get_num_threads();
        
        #pragma omp critical
        {
            printf("Hello World from thread %d of %d threads!\n", thread_id, total_threads);
        }
    }
    
    printf("\nProgram completed successfully!\n");
    return 0;
}
