#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define N 1000000  // Vector size

void vector_add(int *A, int *B, int *C, int n, omp_sched_t schedule_type, const char *schedule_name) {
    omp_set_schedule(schedule_type, 0); // Default chunk size

    // Print schedule header FIRST
    printf("\n--- %s Schedule ---\n", schedule_name);

    double start = omp_get_wtime(); //used to return real world time

    // Temporary array to store per-thread times
    int max_threads = omp_get_max_threads(); // ask it how many threads can I use
    double *thread_times = (double *)calloc(max_threads, sizeof(double)); // create array for each thread to store execution time

    #pragma omp parallel //It creates threads and they have each id then starts to record their start time
    {
        int tid = omp_get_thread_num();
        double thread_start = omp_get_wtime();

        #pragma omp for schedule(runtime) 
        for (int i = 0; i < n; i++) { //start the for loop for the threads to add A and B 
            C[i] = A[i] + B[i];
        }

        double thread_end = omp_get_wtime();
        thread_times[tid] = thread_end - thread_start;
    }

    double end = omp_get_wtime();

    // Print thread times after all threads finish
    for (int i = 0; i < max_threads; i++) {
        if (thread_times[i] > 0)
            printf("Thread %d time: %f seconds\n", i, thread_times[i]);
    }

    // Count number of threads actually used
    int num_threads;
    #pragma omp parallel
    {
        #pragma omp single
        num_threads = omp_get_num_threads();
    }

    printf("Used %d threads\n", num_threads);
    printf("Total execution time: %f seconds\n", end - start);

    // Sample output to print first 5 results of C
    printf("Sample output (C[0..4]): ");
    for (int i = 0; i < 5; i++) {
        printf("%d ", C[i]);
    }
    printf("\n");

    free(thread_times);
}

int main() {  // create empty box to hold integers
    int *A = (int*) malloc(N * sizeof(int));
    int *B = (int*) malloc(N * sizeof(int));
    int *C = (int*) malloc(N * sizeof(int));

    if (A == NULL || B == NULL || C == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Initialize vectors A and B
    for (int i = 0; i < N; i++) {
        A[i] = i;
        B[i] = 2 * i;
    }

    printf("Using %d threads (max available)\n", omp_get_max_threads());

    vector_add(A, B, C, N, omp_sched_static, "Static");
    vector_add(A, B, C, N, omp_sched_dynamic, "Dynamic");

    free(A); //prevent memory leak
    free(B);
    free(C);

    return 0;
}

